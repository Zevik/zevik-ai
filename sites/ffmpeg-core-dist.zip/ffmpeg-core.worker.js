// Placeholder for ffmpeg-core.worker.js
