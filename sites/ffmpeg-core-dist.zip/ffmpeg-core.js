// Placeholder for ffmpeg-core.js
